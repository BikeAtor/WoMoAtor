# Bilder
Die Bilder mit "pixabay" im Namen sind von [Pixabay](https://pixabay.com).

Wenn zusätzlich "clone" angehängt ist, wurden diese nachträglich bearbeitet und können auch frei verwendet werden. Meist ist nur die Größe geändert worden.

